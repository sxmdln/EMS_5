from django.apps import AppConfig


class RegistrationsConfig(AppConfig):
    name = 'registrations'
