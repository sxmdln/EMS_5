from django.contrib import admin

from .models import Event

admin.site.register(Event)

# Register your models here.
